import Cocoa

var greeting = "Hello, playground"

var itemsArray: [String] = ["Pins", "Pens", "Photos"]

print(itemsArray)
